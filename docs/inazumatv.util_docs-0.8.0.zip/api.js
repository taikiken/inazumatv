YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "Android",
        "Browser",
        "Browser.iOS",
        "Chrome",
        "Firefox",
        "IE",
        "Safari",
        "Util",
        "inazumatv"
    ],
    "modules": [
        "inazumatv"
    ],
    "allModules": [
        {
            "displayName": "inazumatv",
            "name": "inazumatv"
        }
    ]
} };
});